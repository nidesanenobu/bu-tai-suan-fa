#ifndef GAIT_CYCLE_CLASSIFIER
#define GAIT_CYCLE_CLASSIFIER

#include <string>

#include "feature_extractor.hpp"

using namespace std;

//步态周期的阶段
//Heel strike（脚跟着地）：脚跟接触地面的瞬间。
//Flat foot（平足）：整个脚掌都接触地面的阶段。
//Mid stance（中期支撑）：体重平衡在足弓上的阶段。
//Heel off（脚跟离地）：脚跟开始离开地面的瞬间。
//Toe off（脚趾离地）：脚趾离开地面的瞬间。
//Mid swing（中期摆动）：腿部在摆动过程中处于中间位置的阶段。
//Toe strike（脚趾着地）：脚趾再次接触地面的瞬间。
enum Gait_cycle_states {
    HEEL_STRIKE,
    FLAT_FOOT,
    MID_STANCE,
    HEEL_OFF,
    TOE_OFF,
    MID_SWING
};

//包含判断条件的具体特征和最大年龄
//用于指定状态机中从一个状态转换到另一个状态所需的特征。
struct StateCriterion {
    Feature_type criterion_feature;
    unsigned int criterion_max_age;
};

//该结构表示状态机的一个状态。
//它包含有关当前状态的信息、下一个状态的索引，
//以及切换到下一个状态所需的条件（特征）。
struct State {
    Gait_cycle_states currentState;
    uint8_t nextState; //下一个状态的索引。

    uint8_t numCriteriaForAccelY;
    StateCriterion *criteriaForAccelY;

    unsigned int numCriteriaForGyroY;
    StateCriterion *criteriaForGyroY;
};

//存储已识别状态的信息（类型和识别时间）。
struct State_recognized_info {
    Gait_cycle_states recognized_state;
    unsigned int time_recognized;
};

//这个类封装了将特征分类为步态周期状态的功能。
class Gait_cycle_classifier {
protected:
    //步态周期的状态（阶段），由状态机使用。
    State gait_cycle_states[6];
    //步态周期的当前状态，由状态机使用。
    State current_state;

    //实时从y轴加速度计信号中提取特征。
    Feature_extractor *accel_y;

    //实时从y轴陀螺仪信号中提取特征。
    Feature_extractor *gyro_y;

public:

    Gait_cycle_classifier();

    ~Gait_cycle_classifier();

    //此函数用于将数据点输入分类器。
    //当识别到一个状态时，state_info的成员将被更新，并且函数返回true。
    //此函数由状态机驱动。
    bool intake_data(int ay_value, int gy_value, unsigned int time_value, State_recognized_info &state_info);
};

//一个用于将状态转换为可读文本的函数，用于演示过程中。
string getStateString(Gait_cycle_states state);

//此函数设置状态机中的每个状态，
//包括状态的名称、切换到下一个状态的条件，
//以及下一个状态的索引。
void initializeStateMachine(State states_array[]);

#endif