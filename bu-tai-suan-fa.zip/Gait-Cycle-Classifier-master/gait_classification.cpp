#include "gait_classification.hpp"

using namespace std;

Gait_cycle_classifier::Gait_cycle_classifier() {
    //初始化状态机。
    initializeStateMachine(gait_cycle_states);
    current_state = gait_cycle_states[0];

    //使用相应的参数初始化accelerometer-y和gyroscope-y的特征提取器。
    accel_y = new Feature_extractor(11000, -7000, 1000, -2000, 99999, -99999, 99999, 99999, 3500, -2500, 150);
    gyro_y = new Feature_extractor(4000, -1000, 99999, -99999, 5500, -1500, 25, 150, -99999, 99999, 99999);
}

Gait_cycle_classifier::~Gait_cycle_classifier() {
    delete accel_y;
    accel_y = nullptr;
    delete gyro_y;
    gyro_y = nullptr;
}

//该函数用于将数据点输入分类器。
//当识别到一个状态时，state_info的成员将被更新，并且函数返回true。
//该函数由状态机驱动。
bool Gait_cycle_classifier::intake_data(int ay_value, int gy_value, unsigned int time_value,
                                        State_recognized_info &state_info) {
    bool feature_generated = false;
    feature_generated = feature_generated || accel_y->processData(ay_value, time_value);
    feature_generated = feature_generated || gyro_y->processData(gy_value, time_value);

    //如果在调用accel_y或gyro_y的processData()函数后，其中任一函数返回true，
    //则在每个(accel_y, gyro_y)中检查是否满足切换到下一个步态周期状态所需的特征。
    if (feature_generated) {
        bool all_features_match = true;

        //对于从accel_y所需的每个判断特征：
        for (uint8_t i = 0; i < current_state.numCriteriaForAccelY; i++) {
            StateCriterion current_criterion = current_state.criteriaForAccelY[i];
            //如果我们不需要从accel_y中寻找任何特征。
            if (current_criterion.criterion_feature == NO_FEATURE) {
                break;
            }

            //检查判断特征是否在特征容器中（如果不在容器中，则没有必要的匹配来进行状态转换）。
            if (!accel_y->isFeatureInVector(current_criterion.criterion_feature, current_criterion.criterion_max_age)) {
                all_features_match = false;
            }
        }

        //对于从gyro_y所需的每个判断特征：
        for (uint8_t i = 0; i < current_state.numCriteriaForGyroY; i++) {
            StateCriterion current_criterion = current_state.criteriaForGyroY[i];
            //如果我们不需要从gyro_y中寻找任何特征。
            if (current_criterion.criterion_feature == NO_FEATURE) {
                break;
            }

            //检查判断特征是否在特征容器中（如果不在容器中，则没有必要的匹配来进行状态转换）。
            if (!gyro_y->isFeatureInVector(current_criterion.criterion_feature, current_criterion.criterion_max_age)) {
                all_features_match = false;
            }
        }

        //如果我们找到了所有我们正在寻找的特征，那么我们可以切换到下一个状态。
        if (all_features_match) {

            //将state_info结构设置为包含有关检测到的状态的信息，以便main()函数可以使用此信息。
            state_info.recognized_state = current_state.currentState;
            state_info.time_recognized = accel_y->getLatestTime();

            //切换到下一个状态。
            current_state = gait_cycle_states[current_state.nextState];

            //在每个步态周期开始时，清除所有年龄大于1000毫秒的特征。
            if (current_state.currentState == HEEL_STRIKE) {
                accel_y->removeOldFeatures(1000);
                gyro_y->removeOldFeatures(1000);
            }

            //返回true以指示状态已更新。
            return true;
        } else {
            //如果状态没有被更新，则返回false。
            return false;
        }
    }
    return false;
}

//一个将状态转换为可读文本的函数，用于演示过程中的展示。
string getStateString(Gait_cycle_states state) {
    if (state == HEEL_STRIKE) {
        return "Heel strike";
    } else if (state == FLAT_FOOT) {
        return "Flat foot";
    } else if (state == MID_STANCE) {
        return "Mid-stance";
    } else if (state == HEEL_OFF) {
        return "Heel-off";
    } else if (state == TOE_OFF) {
        return "Toe-off";
    } else if (state == MID_SWING) {
        return "Mid-swing";
    } else {
        return "Invalid state!";
    }
}

//该函数设置状态机中的每个状态，
//包括状态的名称、切换到下一个状态的条件，
//以及下一个状态的索引。
void initializeStateMachine(State states_array[]) {
    //脚跟着地----------------------------------------------------------
    State heel_strike = {
            .currentState = HEEL_STRIKE,
            .nextState = 1, //下一个状态的索引

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 2,
            .criteriaForGyroY = new StateCriterion[2]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    heel_strike.criteriaForAccelY[0] = {NO_FEATURE, 150};
    heel_strike.criteriaForGyroY[0] = {NEGATIVE_TROUGH, 150};
    heel_strike.criteriaForGyroY[1] = {BREACHED_HIGH_THRESHOLD, 30};

    //将刚刚配置的状态放入状态数组中。
    states_array[0] = heel_strike;

    //平足----------------------------------------------------------
    State flat_foot = {
            .currentState = FLAT_FOOT,
            .nextState = 2, //the index of the next state

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 2,
            .criteriaForGyroY = new StateCriterion[2]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    flat_foot.criteriaForAccelY[0] = {NO_FEATURE, 150};
    flat_foot.criteriaForGyroY[0] = {BREACHED_HIGH_THRESHOLD, 150};
    flat_foot.criteriaForGyroY[1] = {POSITIVE_TROUGH, 30};

    //将刚刚配置的状态放入状态数组中。
    states_array[1] = flat_foot;

    //中期支撑----------------------------------------------------------
    State mid_stance = {
            .currentState = MID_STANCE,
            .nextState = 3, //the index of the next state

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 1,
            .criteriaForGyroY = new StateCriterion[1]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    mid_stance.criteriaForAccelY[0] = {NEUTRAL, 30};
    mid_stance.criteriaForGyroY[0] = {POSITIVE_TROUGH, 250};

    //将刚刚配置的状态放入状态数组中。
    states_array[2] = mid_stance;

    //脚跟离地----------------------------------------------------------
    State heel_off = {
            .currentState = HEEL_OFF,
            .nextState = 4, //下一个状态的索引

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 1,
            .criteriaForGyroY = new StateCriterion[1]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    heel_off.criteriaForAccelY[0] = {NEUTRAL, 150};
    heel_off.criteriaForGyroY[0] = {BREACHED_HIGH_THRESHOLD, 30};

    //将刚刚配置的状态放入状态数组中。
    states_array[3] = heel_off;

    //脚趾离地----------------------------------------------------------
    State toe_off = {
            .currentState = TOE_OFF,
            .nextState = 5, //下一个状态的索引

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 2,
            .criteriaForGyroY = new StateCriterion[2]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    toe_off.criteriaForAccelY[0] = {NO_FEATURE, 150};
    toe_off.criteriaForGyroY[0] = {BREACHED_HIGH_THRESHOLD, 200};
    toe_off.criteriaForGyroY[1] = {POSITIVE_TROUGH, 30};

    //将刚刚配置的状态放入状态数组中。
    states_array[4] = toe_off;

    //中期摆动----------------------------------------------------------
    State mid_swing = {
            .currentState = MID_SWING,
            .nextState = 0, //下一个状态的索引

            .numCriteriaForAccelY = 1,
            .criteriaForAccelY = new StateCriterion[1],

            .numCriteriaForGyroY = 2,
            .criteriaForGyroY = new StateCriterion[2]
    };

    //在accel_y和gyro_y中寻找的特征，以及在计数时可以具有的最大年龄（以毫秒为单位）。
    mid_swing.criteriaForAccelY[0] = {NO_FEATURE, 150};
    mid_swing.criteriaForGyroY[0] = {BREACHED_LOW_THRESHOLD, 250};
    mid_swing.criteriaForGyroY[1] = {NEGATIVE_TROUGH_MIDDLE, 30};

    //将刚刚配置的状态放入状态数组中。
    states_array[5] = mid_swing;
}