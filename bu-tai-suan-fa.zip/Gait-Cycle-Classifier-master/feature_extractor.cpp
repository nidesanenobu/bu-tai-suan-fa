#include "feature_extractor.hpp"

#include <iostream>

using namespace std;

//默认构造函数
Feature_extractor::Feature_extractor()
        :
        latestDataEntry(0),//最近输入的数据值。
        latestDataTime(0),//最近输入的数据的时间。
        dataDiffFromLastEntry(0),//与上一次输入的数据的差值。
        timeDiffFromLastEntry(0),//与上一次输入的数据的时间差。
        slopeFromLastEntry(0),//与上一次输入的数据的斜率（即差值除以时间差）。
        upperThreshold(20000),//上阈值
        lowerThreshold(-20000),//下阈值
        upperThresholdBreachTime(0),//最近一次数据超过上阈值的时间。
        lowerThresholdBreachTime(0),//最近一次数据低于下阈值的时间。
        disableUpperThresholdBreachUntil(0),//在这个时间之前，不会检测数据是否超过上阈值。
        disableLowerThresholdBreachUntil(0),//在这个时间之前，不会检测数据是否低于下阈值。
        slopeUpperThreshold(10000),//斜率的上阈值
        slopeLowerThreshold(-10000),//斜率的下阈值
        slopeUpperThresholdBreachTime(0),//最近一次斜率超过上阈值的时间。
        slopeLowerThresholdBreachTime(0),//最近一次斜率低于下阈值的时间。
        disableSlopeUpperThresholdBreachUntil(0),//在这个时间之前，不会检测斜率是否超过上阈值。
        disableSlopeLowerThresholdBreachUntil(0),//在这个时间之前，不会检测斜率是否低于下阈值。
        minPositiveTroughLength(50),//正谷值的最小长度，只有当一个谷值的长度超过这个值时，才会被认为是一个正谷值。
        minNegativeTroughLength(140),//负谷值的最小长度，只有当一个谷值的长度超过这个值时，才会被认为是一个负谷值。
        troughUpperThreshold(5000),//谷值的上阈值
        troughLowerThreshold(-2000),//谷值的下阈值
        positiveTroughStartTime(0),//最近一次正谷值的开始时间。
        negativeTroughStartTime(0),//最近一次负谷值的开始时间。
        isPositiveTroughActive(false),//表示是否正在检测一个正谷值
        isNegativeTroughActive(false),//表示是否正在检测一个负谷值。
        isPositiveTroughMiddleDetected(false),//表示是否已经检测到一个正谷值的中点。
        isNegativeTroughMiddleDetected(false),//表示是否已经检测到一个负谷值的中点。
        minNeutralLength(200),//中性区间的最小长度，只有当一个区间的长度超过这个值时，才会被认为是一个中性区间。
        upperNeutralThreshold(2500),//中性区间的上阈值。
        lowerNeutralThreshold(-2500),//中性区间的下阈值
        neutralStartTime(0),//最近一次中性区间的开始时间。
        isNeutralActive(false) {}//表示是否正在检测一个中性区间。

//显式构造函数
Feature_extractor::Feature_extractor(int high_threshold_, int low_threshold_, int slope_high_threshold_,
                                     int slope_low_threshold_,
                                     int trough_high_threshold_, int trough_low_threshold_,
                                     unsigned int positive_trough_min_length_, unsigned int negative_trough_min_length_,
                                     int neutral_max_threshold_, int neutral_min_threshold_,
                                     unsigned int neutral_min_length_)
        :
        latestDataEntry(0),
        latestDataTime(0),
        dataDiffFromLastEntry(0),
        timeDiffFromLastEntry(0),
        slopeFromLastEntry(0),
        upperThreshold(high_threshold_),
        lowerThreshold(low_threshold_),
        upperThresholdBreachTime(0),
        lowerThresholdBreachTime(0),
        disableUpperThresholdBreachUntil(0),
        disableLowerThresholdBreachUntil(0),
        slopeUpperThreshold(slope_high_threshold_),
        slopeLowerThreshold(slope_low_threshold_),
        slopeUpperThresholdBreachTime(0),
        slopeLowerThresholdBreachTime(0),
        disableSlopeUpperThresholdBreachUntil(0),
        disableSlopeLowerThresholdBreachUntil(0),
        minPositiveTroughLength(positive_trough_min_length_),
        minNegativeTroughLength(negative_trough_min_length_),
        troughUpperThreshold(trough_high_threshold_),
        troughLowerThreshold(trough_low_threshold_),
        positiveTroughStartTime(0),
        negativeTroughStartTime(0),
        isPositiveTroughActive(false),
        isNegativeTroughActive(false),
        isPositiveTroughMiddleDetected(false),
        isNegativeTroughMiddleDetected(false),
        minNeutralLength(neutral_min_length_),
        upperNeutralThreshold(neutral_max_threshold_),
        lowerNeutralThreshold(neutral_min_threshold_),
        neutralStartTime(0),
        isNeutralActive(false) {}

//每次输入数据点时调用此函数，它会自动识别特征并将它们送到特征容器中。
bool Feature_extractor::processData(int datapoint, unsigned int time) {
    dataDiffFromLastEntry = datapoint - latestDataEntry;    //与上一次相比，这条的值变化。
    timeDiffFromLastEntry = time - latestDataTime;        //与上一次相比，这条的时间变化。

    //计算与上一个数据点的斜率（但如果分母是零则不进行计算）。
    if (timeDiffFromLastEntry > 0) {
        slopeFromLastEntry = dataDiffFromLastEntry / (int) timeDiffFromLastEntry;
    }

    latestDataEntry = datapoint;
    latestDataTime = time;

    //用于跟踪是否识别到任何新特征。
    bool feature_created = false;

    //检查数据是否超过了上阈值。
    if (latestDataEntry > upperThreshold && latestDataTime >= disableUpperThresholdBreachUntil) {
        //在150毫秒内防止其触发。
        disableUpperThresholdBreachUntil = latestDataTime + 150;

        //创建特征，设置其类型和时间，并将其送入特征容器中。
        auto *recent_spike = new Feature();
        recent_spike->type = BREACHED_HIGH_THRESHOLD;
        recent_spike->start_time = latestDataTime;
        recent_spike->end_time = latestDataTime;

        feature_vector.push_back(recent_spike);
        feature_created = true;
    }
        //检查数据是否低于了下阈值。
    else if (latestDataEntry < lowerThreshold && latestDataTime >= disableLowerThresholdBreachUntil) {
        //在150毫秒内防止其触发。
        disableLowerThresholdBreachUntil = latestDataTime + 150;

        //创建特征，设置其类型和时间，并将其送入特征容器中。
        auto *recent_spike = new Feature();
        recent_spike->type = BREACHED_LOW_THRESHOLD;
        recent_spike->start_time = latestDataTime;
        recent_spike->end_time = latestDataTime;

        feature_vector.push_back(recent_spike);
        feature_created = true;
    }
        //检查数据是否超过了斜率的上阈值。
    else if (slopeFromLastEntry > slopeUpperThreshold && latestDataTime >= disableSlopeUpperThresholdBreachUntil) {
        //在150毫秒内防止其触发。
        disableSlopeUpperThresholdBreachUntil = latestDataTime + 150;

        //创建特征，设置其类型和时间，并将其送入特征容器中。
        auto *recent_spike = new Feature();
        recent_spike->type = BREACHED_SLOPE_HIGH_THRESHOLD;
        recent_spike->start_time = latestDataTime;
        recent_spike->end_time = latestDataTime;

        feature_vector.push_back(recent_spike);
        feature_created = true;
    }
        //检查数据是否超过了斜率的上阈值。
    else if (slopeFromLastEntry < slopeLowerThreshold && latestDataTime >= disableSlopeLowerThresholdBreachUntil) {
        //在150毫秒内防止其触发。
        disableSlopeLowerThresholdBreachUntil = latestDataTime + 150;

        //创建特征，设置其类型和时间，并将其送入特征容器中。
        auto *recent_spike = new Feature();
        recent_spike->type = BREACHED_SLOPE_LOW_THRESHOLD;
        recent_spike->start_time = latestDataTime;
        recent_spike->end_time = latestDataTime;

        feature_vector.push_back(recent_spike);
        feature_created = true;
    }

    //如果数据超过了检测正谷值的阈值，准备检测正谷值
    if (latestDataEntry > troughUpperThreshold && !isPositiveTroughActive) {
        isPositiveTroughActive = true;
        positiveTroughStartTime = latestDataTime;
    }
        //如果数据低于检测负谷值的阈值，准备检测负谷值
    else if (latestDataEntry < troughLowerThreshold && !isNegativeTroughActive) {
        isNegativeTroughActive = true;
        negativeTroughStartTime = latestDataTime;
    }

    //如果我们已经在正谷值内持续了最小所需的时间，将'POSITIVE_TROUGH_MIDDLE'特征送入特征容器
    if (isPositiveTroughActive && !isPositiveTroughMiddleDetected &&
        latestDataTime >= minPositiveTroughLength + positiveTroughStartTime) {
        isPositiveTroughMiddleDetected = true;

        auto *recent_trough = new Feature();
        recent_trough->type = POSITIVE_TROUGH_MIDDLE;
        recent_trough->start_time = positiveTroughStartTime;
        recent_trough->end_time = latestDataTime;

        feature_vector.push_back(recent_trough);
        feature_created = true;
    }
        //如果我们已经在负谷值内持续了最小所需的时间，将'NEGATIVE_TROUGH_MIDDLE'特征送入特征容器
    else if (isNegativeTroughActive && !isNegativeTroughMiddleDetected &&
             latestDataTime >= minNegativeTroughLength + negativeTroughStartTime) {
        isNegativeTroughMiddleDetected = true;

        auto *recent_trough = new Feature();
        recent_trough->type = NEGATIVE_TROUGH_MIDDLE;
        recent_trough->start_time = negativeTroughStartTime;
        recent_trough->end_time = latestDataTime;

        feature_vector.push_back(recent_trough);
        feature_created = true;
    }

    //如果我们准备检测正谷值，而信号已经回落到阈值以下
    if (isPositiveTroughActive && latestDataEntry <= troughUpperThreshold) {
        isPositiveTroughActive = false;

        //如果信号在阈值以上的时间足够长，将POSITIVE_TROUGH特征送入特征容器
        if (latestDataTime >= minPositiveTroughLength + positiveTroughStartTime) {
            auto *recent_trough = new Feature();
            recent_trough->type = POSITIVE_TROUGH;
            recent_trough->start_time = positiveTroughStartTime;
            recent_trough->end_time = latestDataTime;

            feature_vector.push_back(recent_trough);
            feature_created = true;
        }
        //否则，丢弃当前的潜在谷值，开始寻找下一个的开始
        isPositiveTroughMiddleDetected = false;
    }
    //如果我们准备检测负谷值，而信号已经回升到阈值以上
    if (isNegativeTroughActive && latestDataEntry >= troughLowerThreshold) {// && isPositiveTroughActive == false){
        isNegativeTroughActive = false;

        //如果信号在阈值以下的时间足够长，将NEGATIVE_TROUGH特征送入特征容器
        if (latestDataTime >= minNegativeTroughLength + negativeTroughStartTime) {
            auto *recent_trough = new Feature();
            recent_trough->type = NEGATIVE_TROUGH;
            recent_trough->start_time = negativeTroughStartTime;
            recent_trough->end_time = latestDataTime;

            feature_vector.push_back(recent_trough);
            feature_created = true;
        }

        //否则，丢弃当前的潜在谷值，开始寻找下一个的开始
        isNegativeTroughMiddleDetected = false;
    }

    //如果信号在中性阈值之间，准备将NEUTRAL特征送入特征容器
    if (latestDataEntry < upperNeutralThreshold && latestDataEntry > lowerNeutralThreshold &&
        !isNeutralActive) {
        isNeutralActive = true;
        neutralStartTime = latestDataTime;
    }

    //如果我们已经准备检测NEUTRAL特征，而信号离开了中性范围或者特征时间已到
    if (isNeutralActive &&
        (latestDataTime >= neutralStartTime + minNeutralLength || latestDataEntry >= upperNeutralThreshold ||
         latestDataEntry <= lowerNeutralThreshold)) {
        //如果特征时间已到，将NEUTRAL特征送入特征容器
        if (latestDataTime >= neutralStartTime + minNeutralLength) {
            auto *recent_neutral_centre = new Feature();

            recent_neutral_centre->type = NEUTRAL;
            recent_neutral_centre->start_time = neutralStartTime;
            recent_neutral_centre->end_time = latestDataTime;

            feature_vector.push_back(recent_neutral_centre);
            feature_created = true;
        }

        //否则，等待下一个中性特征开始
        isNeutralActive = false;
    }

    //如果任何特征被送入特征容器，返回true
    if (feature_created) {
        return true;
    } else {
        //否则返回false
        return false;
    }
}

//这个函数在特征容器中搜索特定类型的特征，这些特征在特定的毫秒年龄内
bool Feature_extractor::isFeatureInVector(Feature_type feature, unsigned int max_feature_age) {
    if (feature_vector.empty()) {
        return false;
    }

    auto iter = feature_vector.end() - 1;

    while (iter != (feature_vector.begin() - 1) && latestDataTime - (*iter)->end_time < max_feature_age) {
        if ((*iter)->type == feature) {
            return true;
        }
        iter--;
    }
    return false;
}

//将特征容器中年龄比max_age更大的元素清空
void Feature_extractor::removeOldFeatures(unsigned int max_age) {
    auto iter = feature_vector.end() - 1;

    uint8_t count = 0;

    while (iter != feature_vector.begin() - 1 && (*iter)->end_time + max_age > latestDataTime) {
        iter--;
        count++;
    }

    if (count == 0) {
        return;
    }

    vector<Feature *> trimmed_vector(feature_vector.end() - 1 - count, feature_vector.end() - 1);

    feature_vector = trimmed_vector;
}

//返回最新输入数据点的时间样本
unsigned int Feature_extractor::getLatestTime() const {
    return latestDataTime;
}

//从最近的开始，打印特征容器中的特征
void Feature_extractor::printDetectedFeatures() {
    auto iter = feature_vector.end() - 1;

    while (iter != feature_vector.begin() - 1) {
        cout << "Feature: " << (*iter)->type << " time:" << (*iter)->end_time << endl;
        iter--;
    }
}
