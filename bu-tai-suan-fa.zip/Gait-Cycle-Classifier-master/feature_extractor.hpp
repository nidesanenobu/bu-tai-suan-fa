#ifndef FEATURE_EXTRACTOR_HPP
#define FEATURE_EXTRACTOR_HPP

#include <vector>

using namespace std;

//Feature_extractor能够在信号中检测到的特征
enum Feature_type {
    NO_FEATURE = 0,//表示当前没有检测到任何特征。
    BREACHED_HIGH_THRESHOLD,//表示信号已经超过了设定的高阈值。
    BREACHED_LOW_THRESHOLD,//表示信号已经低于设定的低阈值。
    BREACHED_SLOPE_HIGH_THRESHOLD,//表示信号的斜率已经超过了设定的高阈值。
    BREACHED_SLOPE_LOW_THRESHOLD,//表示信号的斜率已经低于设定的低阈值。
    POSITIVE_TROUGH,//表示信号中出现了一个正的谷值。即信号的强度在一段时间内达到了一个局部最小值，然后又开始上升。
    NEGATIVE_TROUGH,//表示信号中出现了一个负的谷值。即信号的强度在一段时间内达到了一个局部最大值，然后又开始下降。
    POSITIVE_TROUGH_MIDDLE,//表示信号中出现了一个正的中间谷值。即信号的强度在一段时间内达到了一个局部最小值，然后又开始上升，但这个谷值并不是最小值。
    NEGATIVE_TROUGH_MIDDLE,//表示信号中出现了一个负的中间谷值。即信号的强度在一段时间内达到了一个局部最大值，然后又开始下降，但这个谷值并不是最大值。
    NEUTRAL//这表示信号处于中性状态，没有特别的特征。
};

//用于存储与某个特征相关的信息
struct Feature {
    Feature_type type;
    unsigned int start_time;
    unsigned int end_time;

    Feature() : type(NO_FEATURE), start_time(0), end_time(0) {}
};

//封装了Feature_extractor的所有数据和函数，它可以接受离散的输入信号并在其中检测特征。
class Feature_extractor {
protected:
    //与最新数据点相关的信息。
    int latestDataEntry;
    unsigned int latestDataTime;
    int dataDiffFromLastEntry;
    unsigned int timeDiffFromLastEntry;
    int slopeFromLastEntry;

    //用于检测'BREACHED_HIGH_THRESHOLD'和'BREACHED_LOW_THRESHOLD'特征的信息。
    int upperThreshold;
    int lowerThreshold;
    unsigned int upperThresholdBreachTime;
    unsigned int lowerThresholdBreachTime;
    unsigned int disableUpperThresholdBreachUntil;
    unsigned int disableLowerThresholdBreachUntil;

    //用于检测'BREACHED_SLOPE_HIGH_THRESHOLD'和'BREACHED_SLOPE_LOW_THRESHOLD'特征的信息。
    int slopeUpperThreshold;
    int slopeLowerThreshold;
    unsigned int slopeUpperThresholdBreachTime;
    unsigned int slopeLowerThresholdBreachTime;
    unsigned int disableSlopeUpperThresholdBreachUntil;
    unsigned int disableSlopeLowerThresholdBreachUntil;

    //用于检测'POSITIVE_TROUGH'、'NEGATIVE_TROUGH'、'POSITIVE_TROUGH_MIDDLE'和'NEGATIVE_TROUGH_MIDDLE'特征的信息。
    unsigned int minPositiveTroughLength;
    unsigned int minNegativeTroughLength;
    int troughUpperThreshold;
    int troughLowerThreshold;
    unsigned int positiveTroughStartTime;
    unsigned int negativeTroughStartTime;
    bool isPositiveTroughActive;
    bool isNegativeTroughActive;
    bool isPositiveTroughMiddleDetected;
    bool isNegativeTroughMiddleDetected;

    //用于检测'NEUTRAL'特征的信息。
    unsigned int minNeutralLength;
    int upperNeutralThreshold;
    int lowerNeutralThreshold;
    unsigned int neutralStartTime;
    bool isNeutralActive;

    //检测到的特征被送到这个容器中。
    vector<Feature *> feature_vector;

public:
    //默认构造函数
    Feature_extractor();

    //显式构造函数，用于输入特定参数，确定被检测为特征的波形。
    Feature_extractor(int high_threshold_, int low_threshold_, int slope_high_threshold_, int slope_low_threshold_,
                      int trough_high_threshold_, int trough_low_threshold_, unsigned int positive_trough_min_length_,
                      unsigned int negative_trough_min_length_,
                      int neutral_max_threshold_, int neutral_min_threshold_, unsigned int neutral_min_length_);

    //每次输入数据点时都会调用此函数，它会自动识别特征并将它们送到特征容器中
    bool processData(int datapoint, unsigned int time);

    //该函数在特定的时间范围内（以毫秒为单位）搜索特征容器中的特定类型的特征
    bool isFeatureInVector(Feature_type feature, unsigned int max_feature_age);

    //将特征容器中的年龄大于max_age的元素进行移除。
    void removeOldFeatures(unsigned int max_age);

    //返回最新输入数据点的时间样本。
    unsigned int getLatestTime() const;

    //打印迄今为止检测到的特征，从最近的开始。
    void printDetectedFeatures();
};


#endif