#include <iostream>
#include <string>

#include "feature_extractor.hpp"
#include "gait_classification.hpp"
#include "csvparser.h"

using namespace std;

//解析指定的.csv文件，并将数据放入time[]、ay[]、gyp[]数组中，并记录数据的长度到data_length。
bool parseCSV(unsigned int time[], int ay[], int gy[], unsigned int &data_length, const string &file_location);

//main.cpp文件纯粹用于展示我的分类器的功能。分类器被封装在gait_classification.cpp文件中的Gait_cycle_classifier中。
int main() {
    //用于存储加速度计y轴（accelerometer-y）数据和陀螺仪y轴（gyroscope-y）数据的数组。
    unsigned int timeVals[941];
    int accelYVals[941];
    int gyroYVals[941];
    unsigned int dataLen = 0;

    //将第一个数据集的.csv数据读入数据数组。
    if (!parseCSV(timeVals, accelYVals, gyroYVals, dataLen, "datasets/walkData1.csv")) {
        cout << "Error reading .csv file!" << endl;
        return -1;
    }

    //实例化分类器classifier1
    auto *classifier1 = new Gait_cycle_classifier();

    //用于接收新识别的状态的信息。
    State_recognized_info latest_state_info{};

    cout << "Starting to input \"walkData1.csv\"..." << endl;

    //将数据从第一个输入到最后一个输入分类器，模拟分类器的实时应用。
    for (unsigned int i = 0; i < dataLen; i++) {

        //如果识别出了新的状态（阶段），则打印出该状态以及识别出它的时间。
        if (classifier1->intake_data(accelYVals[i], gyroYVals[i], timeVals[i], latest_state_info)) {
            cout << "Just recognized: " << getStateString(latest_state_info.recognized_state) << " at time: "
                 << latest_state_info.time_recognized << endl;
        }

    }

    cout << "Finished inputting \"walkData1.csv\"" << endl;

    delete classifier1;


    //将第二个数据集的.csv数据读入相同的数据数组。
    if (!parseCSV(timeVals, accelYVals, gyroYVals, dataLen, "datasets/walkData2.csv")) {
        cout << "Error reading .csv file!" << endl;
        return -1;
    }

    //实例化另一个分类器classifer2
    auto *classifer2 = new Gait_cycle_classifier();

    cout << endl << "Starting to input \"walkData2.csv\"..." << endl;

    for (unsigned int i = 0; i < dataLen; i++) {

        //如果识别出了新的状态（阶段），则打印出该状态以及识别出它的时间。
        if (classifer2->intake_data(accelYVals[i], gyroYVals[i], timeVals[i], latest_state_info)) {
            cout << "Just recognized: " << getStateString(latest_state_info.recognized_state) << " at time: "
                 << latest_state_info.time_recognized << endl;
        }

    }

    cout << "Finished inputting \"walkData2.csv\"" << endl;

    delete classifer2;

    return 0;
}

//解析指定的.csv文件，并将数据放入time[]、ay[]、gyp[]数组中，并记录数据的长度到data_length。
bool parseCSV(unsigned int time[], int ay[], int gy[], unsigned int &data_length, const string &file_location) {
    data_length = 0;

    CsvParser *csvparser = CsvParser_new(file_location.c_str(), ",", 0);

    if (!csvparser) {
        return false;
    }

    CsvRow *row;

    row = CsvParser_getRow(csvparser);
    CsvParser_destroy_row(row);
    row = CsvParser_getRow(csvparser);
    CsvParser_destroy_row(row);

    while ((row = CsvParser_getRow(csvparser))) {
        const char **rowFields = CsvParser_getFields(row);
        if (CsvParser_getNumFields(row) < 15) {
            CsvParser_destroy_row(row);
            break;
        }

        time[data_length] = static_cast<unsigned int>(stoi(rowFields[1]));
        ay[data_length] = stoi(rowFields[3]);
        gy[data_length] = stoi(rowFields[6]);

        CsvParser_destroy_row(row);
        data_length++;
    }

    CsvParser_destroy(csvparser);

    return true;
}